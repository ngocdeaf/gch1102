var mongoose = require('mongoose');

var LegoSchema  = mongoose.Schema(
   {
      name : String,
      brand : String,
      category : String,
      instock : Number,
      price: Number,
      image : String,
      date: Date
   }
);

var ToyModel = mongoose.model("MoHinh", ToySchema, "lego");
module.exports = ToyModel;